# patient_report_system.py

from flask import Flask, request, render_template, send_file
from fpdf import FPDF
import os

# Initialize Flask App
app = Flask(__name__)

# Route for Input Form
@app.route('/')
def index():
    return render_template('form.html')

# Route for Generating Report
@app.route('/generate_report', methods=['POST'])
def generate_report():
    # Collect Data from Form
    data = request.form.to_dict()

    # Create PDF
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    # Add Report Content
    pdf.cell(200, 10, txt="Patient Report", ln=True, align='C')
    pdf.ln(10)
    for key, value in data.items():
        pdf.cell(200, 10, txt=f"{key.capitalize()}: {value}", ln=True)

    # Save PDF to Temporary File
    file_path = "patient_report.pdf"
    pdf.output(file_path)

    # Send the File to User
    return send_file(file_path, as_attachment=True)

# HTML Form Template
@app.route('/form.html')
def form():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Patient Report Generator</title>
    </head>
    <body>
        <h1>Generate Patient Report</h1>
        <form action="/generate_report" method="POST">
            <label for="name">Patient Name:</label>
            <input type="text" id="name" name="name" required><br><br>
            
            <label for="age">Age:</label>
            <input type="number" id="age" name="age" required><br><br>
            
            <label for="date">Date of Visit:</label>
            <input type="date" id="date" name="date" required><br><br>
            
            <label for="complaint">Chief Complaint:</label>
            <textarea id="complaint" name="complaint" required></textarea><br><br>
            
            <label for="diagnosis">Diagnosis:</label>
            <textarea id="diagnosis" name="diagnosis" required></textarea><br><br>
            
            <label for="findings">Findings:</label>
            <textarea id="findings" name="findings" required></textarea><br><br>
            
            <label for="treatment">Treatment Plan:</label>
            <textarea id="treatment" name="treatment" required></textarea><br><br>
            
            <label for="instructions">Follow-Up Instructions:</label>
            <textarea id="instructions" name="instructions" required></textarea><br><br>
            
            <label for="notes">Additional Notes:</label>
            <textarea id="notes" name="notes"></textarea><br><br>
            
            <button type="submit">Generate Report</button>
        </form>
    </body>
    </html>
    '''

# Run the App
if __name__ == '__main__':
    app.run(debug=True)
